#define PluginVersion "ReactNative/11.0.0"

@interface RNBatch: NSObject

+(void)start;

@end
